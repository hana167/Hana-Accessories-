import { useState, useEffect } from 'react'
import { useSearchParams } from 'react-router-dom'
import { getProducts, getCategories } from '../utils/api'
import ProductCard from '../components/ProductCard'
import SkeletonCard from '../components/SkeletonCard'

function Products({ setCart }) {
  const [searchParams, setSearchParams] = useSearchParams()
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [categories, setCategories] = useState([])
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [search, setSearch] = useState(searchParams.get('search') || '')
  const [searchInput, setSearchInput] = useState(searchParams.get('search') || '')
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || '')
  const [ordering, setOrdering] = useState('-rating')

  useEffect(() => {
    getCategories().then(data => setCategories(data.results || []))
  }, [])

  useEffect(() => {
    setLoading(true); setError(null)
    getProducts({ search, page, category: selectedCategory, ordering, pageSize: 12 })
      .then(data => { setProducts(data.results || []); setTotalPages(Math.ceil((data.count || 0) / 12)) })
      .catch(() => setError('Failed to load products.'))
      .finally(() => setLoading(false))
  }, [search, page, selectedCategory, ordering])

  useEffect(() => {
    const s = searchParams.get('search') || ''
    const cat = searchParams.get('category') || ''
    setSearch(s); setSearchInput(s); setSelectedCategory(cat); setPage(1)
  }, [searchParams])

  function handleSearch(e) {
    e.preventDefault()
    setSearch(searchInput); setPage(1)
    setSearchParams(searchInput ? { search: searchInput } : {})
  }

  return (
    <main className="pt-32 pb-24 px-8 max-w-[1600px] mx-auto min-h-screen">
      <header className="mb-16">
        <h1 className="font-headline text-5xl md:text-6xl text-on-surface mb-4 tracking-tight">The Curation</h1>
        <p className="font-body text-on-surface-variant max-w-2xl text-lg opacity-80">Discover meticulously crafted accessories designed to embody quiet luxury and timeless sophistication.</p>
      </header>

      <div className="flex flex-col lg:flex-row gap-12">
        <aside className="w-full lg:w-64 space-y-10">
          <form onSubmit={handleSearch}>
            <label className="font-label text-xs tracking-[0.1rem] text-primary uppercase mb-6 block">Search</label>
            <div className="flex items-center bg-surface-container-lowest rounded-xl px-4 py-3 border border-outline-variant/15 focus-within:ring-primary/50 focus-within:ring-2">
              <span className="material-symbols-outlined text-outline mr-2" style={{ fontSize: '16px' }}>search</span>
              <input value={searchInput} onChange={e => setSearchInput(e.target.value)} className="bg-transparent outline-none font-body text-sm text-on-surface placeholder:text-outline/50 flex-1" placeholder="Find jewelry..." type="text" />
            </div>
            <button type="submit" className="mt-4 w-full silk-gradient text-on-primary-fixed py-3 rounded-xl font-label text-sm font-semibold tracking-wider hover:shadow-[0_0_25px_rgba(225,153,153,0.4)] transition-all">Search</button>
          </form>

          <section>
            <label className="font-label text-xs tracking-[0.1rem] text-primary uppercase mb-6 block">Sort By</label>
            <select value={ordering} onChange={e => { setOrdering(e.target.value); setPage(1) }} className="w-full bg-surface-container-lowest border-none rounded-xl text-on-surface-variant font-body focus:ring-primary/50 focus:ring-2 outline-none py-3 px-4">
              <option value="-rating">Popularity</option>
              <option value="-released">Newest</option>
              <option value="name">Name (A-Z)</option>
            </select>
          </section>

          <section>
            <label className="font-label text-xs tracking-[0.1rem] text-primary uppercase mb-6 block">Category</label>
            <div className="space-y-4">
              <label className="flex items-center gap-3 group cursor-pointer">
                <input type="radio" name="category" checked={selectedCategory === ''} onChange={() => { setSelectedCategory(''); setPage(1); setSearchParams({}) }} className="border-outline-variant bg-transparent text-primary focus:ring-primary/20" />
                <span className={`transition-colors font-body ${selectedCategory === '' ? 'text-on-surface' : 'text-on-surface-variant group-hover:text-on-surface'}`}>All Jewelry</span>
              </label>
              {categories.map(c => (
                <label key={c.id} className="flex items-center gap-3 group cursor-pointer">
                  <input type="radio" name="category" checked={selectedCategory === c.slug} onChange={() => { setSelectedCategory(c.slug); setPage(1); setSearchParams({ category: c.slug }) }} className="border-outline-variant bg-transparent text-primary focus:ring-primary/20" />
                  <span className={`transition-colors font-body ${selectedCategory === c.slug ? 'text-on-surface' : 'text-on-surface-variant group-hover:text-on-surface'}`}>{c.name}</span>
                </label>
              ))}
            </div>
          </section>
        </aside>

        <div className="flex-1">
          {error && <div className="text-error text-center py-16 font-semibold">{error}</div>}

          {!loading && !error && products.length === 0 && (
            <div className="flex flex-col items-center justify-center py-24 text-center glass-card rounded-xl">
              <span className="material-symbols-outlined text-6xl text-outline-variant mb-6" style={{ fontVariationSettings: "'wght' 100" }}>search_off</span>
              <h2 className="text-2xl font-headline italic mb-2 text-on-surface">No pieces found</h2>
              <p className="font-body text-on-surface-variant mb-8 max-w-xs">We couldn't find any jewelry matching your request.</p>
              <button onClick={() => { setSearch(''); setSearchInput(''); setSelectedCategory(''); setPage(1); setSearchParams({}) }} className="px-8 py-3 glass-card text-on-surface font-semibold rounded-lg hover:border-primary/50 transition-all">
                Clear Filters
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-8">
            {loading ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />) : products.map(p => <ProductCard key={p.id} product={p} setCart={setCart} />)}
          </div>

          {!loading && totalPages > 1 && (
            <div className="mt-20 flex justify-center gap-2">
              <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="w-12 h-12 flex items-center justify-center rounded-xl border border-outline-variant/30 text-on-surface hover:bg-surface-container transition-colors disabled:opacity-30 disabled:cursor-not-allowed">
                <span className="material-symbols-outlined">chevron_left</span>
              </button>
              {Array.from({ length: Math.min(totalPages, 5) }).map((_, i) => (
                <button key={i + 1} onClick={() => setPage(i + 1)} className={`w-12 h-12 flex items-center justify-center rounded-xl font-label tracking-widest transition-colors ${page === i + 1 ? 'border border-primary text-primary' : 'border border-outline-variant/30 text-on-surface hover:bg-surface-container'}`}>{i + 1}</button>
              ))}
              <button disabled={page === totalPages} onClick={() => setPage(p => p + 1)} className="w-12 h-12 flex items-center justify-center rounded-xl border border-outline-variant/30 text-on-surface hover:bg-surface-container transition-colors disabled:opacity-30 disabled:cursor-not-allowed">
                <span className="material-symbols-outlined">chevron_right</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}

export default Products
