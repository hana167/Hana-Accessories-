import { useState } from 'react'

function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [sent, setSent] = useState(false)

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  function handleSubmit(e) {
    e.preventDefault()
    setSent(true)
    setForm({ name: '', email: '', message: '' })
    setTimeout(() => setSent(false), 4000)
  }

  return (
    <main className="pt-32 pb-24 px-8 max-w-[1440px] mx-auto min-h-screen">
      <header className="mb-16">
        <h1 className="font-headline text-5xl md:text-6xl text-on-surface mb-4 tracking-tight">Contact Us</h1>
        <p className="font-body text-on-surface-variant max-w-xl text-lg opacity-80">
          Our concierges are available to assist with inquiries, styling advice, or bespoke requests.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
        <div className="md:col-span-7 glass-card p-12 rounded-2xl relative overflow-hidden">
          <div className="absolute top-0 start-0 w-1 h-full silk-gradient"></div>

          {sent && (
            <div className="mb-8 px-6 py-4 bg-primary/10 border border-primary/30 rounded-xl text-primary font-body font-medium text-sm">
              Your message has been sent. A boutique representative will contact you shortly.
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-10 relative z-10">
            <div className="relative">
              <input
                name="name" value={form.name} onChange={handleChange} required
                id="c-name" placeholder=" " type="text"
                className="peer w-full bg-transparent border-0 border-b border-outline-variant/30 focus:border-primary-container focus:ring-0 transition-all py-4 px-0 font-body text-lg outline-none text-on-surface"
              />
              <label htmlFor="c-name" className="absolute start-0 top-4 text-outline-variant font-label uppercase text-[10px] tracking-widest transition-all peer-focus:-top-4 peer-focus:text-primary-container peer-[:not(:placeholder-shown)]:-top-4">
                Name
              </label>
            </div>
            <div className="relative">
              <input
                name="email" value={form.email} onChange={handleChange} required
                id="c-email" placeholder=" " type="email"
                className="peer w-full bg-transparent border-0 border-b border-outline-variant/30 focus:border-primary-container focus:ring-0 transition-all py-4 px-0 font-body text-lg outline-none text-on-surface"
              />
              <label htmlFor="c-email" className="absolute start-0 top-4 text-outline-variant font-label uppercase text-[10px] tracking-widest transition-all peer-focus:-top-4 peer-focus:text-primary-container peer-[:not(:placeholder-shown)]:-top-4">
                Email
              </label>
            </div>
            <div className="relative">
              <textarea
                name="message" value={form.message} onChange={handleChange} required
                id="c-message" placeholder=" " rows="4"
                className="peer w-full bg-transparent border-0 border-b border-outline-variant/30 focus:border-primary-container focus:ring-0 transition-all py-4 px-0 font-body text-lg resize-none outline-none text-on-surface"
              />
              <label htmlFor="c-message" className="absolute start-0 top-4 text-outline-variant font-label uppercase text-[10px] tracking-widest transition-all peer-focus:-top-4 peer-focus:text-primary-container peer-[:not(:placeholder-shown)]:-top-4">
                Message & Details
              </label>
            </div>

            <button type="submit" className="w-full py-5 silk-gradient text-on-primary-fixed font-label font-bold uppercase tracking-widest rounded-xl hover:shadow-[0_0_30px_rgba(225,153,153,0.3)] transition-all active:scale-[0.98]">
              Send Inquiry
            </button>
          </form>
        </div>

        <div className="md:col-span-5 flex flex-col gap-6">
          <div className="rounded-2xl overflow-hidden glass-card h-80 relative p-1">
            <iframe
              title="Cairo Egypt Map"
              src="https://www.openstreetmap.org/export/embed.html?bbox=31.20,30.00,31.30,30.10&layer=mapnik&marker=30.05,31.25"
              width="100%"
              height="100%"
              style={{ border: 0, filter: 'invert(0.9) hue-rotate(300deg) brightness(0.7) sepia(0.5)' }}
              loading="lazy"
              className="rounded-xl"
            />
            <div className="absolute bottom-4 start-1/2 -translate-x-1/2 bg-surface/90 backdrop-blur-md px-6 py-3 rounded-xl border border-primary/20 flex flex-col items-center">
              <span className="font-headline italic text-primary-container text-lg">Cairo Atelier</span>
              <span className="text-[10px] font-label uppercase tracking-widest text-on-surface-variant font-bold mt-1">Zamalek, Cairo</span>
            </div>
          </div>

          <div className="glass-card p-8 rounded-2xl flex flex-col gap-8">
            <div className="flex items-start gap-5">
              <div className="w-12 h-12 rounded-xl bg-surface-container flex items-center justify-center flex-shrink-0 border border-outline-variant/15">
                <span className="material-symbols-outlined text-primary/80" style={{ fontSize: '20px' }}>mail</span>
              </div>
              <div>
                <div className="text-[10px] font-label uppercase tracking-widest text-outline mb-1 font-bold">Inquiries</div>
                <div className="text-on-surface font-body">concierge@hana-accessories.com</div>
              </div>
            </div>

            <div className="flex items-start gap-5">
              <div className="w-12 h-12 rounded-xl bg-surface-container flex items-center justify-center flex-shrink-0 border border-outline-variant/15">
                <span className="material-symbols-outlined text-primary/80" style={{ fontSize: '20px' }}>phone_in_talk</span>
              </div>
              <div>
                <div className="text-[10px] font-label uppercase tracking-widest text-outline mb-1 font-bold">Client Care</div>
                <div className="text-on-surface font-body">+20 10 1234 5678</div>
              </div>
            </div>
            
            <div className="flex items-start gap-5">
              <div className="w-12 h-12 rounded-xl bg-surface-container flex items-center justify-center flex-shrink-0 border border-outline-variant/15">
                <span className="material-symbols-outlined text-primary/80" style={{ fontSize: '20px' }}>schedule</span>
              </div>
              <div>
                <div className="text-[10px] font-label uppercase tracking-widest text-outline mb-1 font-bold">Hours</div>
                <div className="text-on-surface font-body">Sun-Thu, 10:00 - 20:00 (EET)</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}

export default Contact
