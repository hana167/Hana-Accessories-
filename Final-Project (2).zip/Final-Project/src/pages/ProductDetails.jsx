import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getProductById, getRelatedProducts, getStablePrice } from '../utils/api'
import { addToCart } from '../utils/cart'
import ProductCard from '../components/ProductCard'

function ProductDetails({ setCart }) {
  const { id } = useParams()
  const [product, setProduct] = useState(null)
  const [related, setRelated] = useState([])
  const [loading, setLoading] = useState(true)
  const [qty, setQty] = useState(1)

  useEffect(() => {
    setLoading(true)
    Promise.all([getProductById(id), getRelatedProducts(id)])
      .then(([p, r]) => {
        setProduct(p)
        setRelated(r.results?.slice(0, 3) || [])
        window.scrollTo(0, 0)
      })
      .finally(() => setLoading(false))
  }, [id])

  if (loading) return (
    <div className="pt-40 text-center min-h-screen">
      <div className="inline-block w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
    </div>
  )

  if (!product) return <div className="pt-40 text-center min-h-screen font-headline text-2xl italic">Jewelry piece not found.</div>

  const price = getStablePrice(product)

  function handleAddToCart() {
    const item = { id: product.id, name: product.name, image: product.background_image, price: parseFloat(price), category: product.category?.name || 'Accessory', quantity: qty }
    setCart(addToCart(item))
  }

  return (
    <main className="pt-24 pb-20 px-6 max-w-[1600px] mx-auto">
      <div className="mb-12 flex gap-4 text-xs font-label uppercase tracking-widest text-on-surface-variant/60">
        <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        <span>/</span>
        <Link to={`/products?category=${product.category?.slug}`} className="hover:text-primary transition-colors">{product.category?.name}</Link>
        <span>/</span>
        <span className="text-primary-container">{product.name}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
        <div className="lg:col-span-7 grid grid-cols-12 gap-4 h-full">
          <div className="col-span-2 flex flex-col gap-4">
            {product.short_screenshots?.map((s, i) => (
              <div key={i} className={`aspect-square bg-surface-container-low rounded-xl overflow-hidden cursor-pointer border ${i === 0 ? 'border-primary-container/40 p-1' : 'border-transparent hover:border-primary-container/20'} transition-all`}>
                <img src={s.image} alt="Detail" className={`w-full h-full object-cover ${i === 0 ? 'rounded-lg' : ''}`} />
              </div>
            ))}
          </div>
          <div className="col-span-10 relative group">
            <div className="aspect-[4/5] bg-surface-container-low rounded-xl overflow-hidden shadow-[0_40px_80px_-20px_rgba(0,0,0,0.5)]">
              <img src={product.background_image} alt={product.name} className="w-full h-full object-cover" />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-background/40 to-transparent pointer-events-none"></div>
          </div>
        </div>

        <div className="lg:col-span-5 flex flex-col gap-8 lg:sticky lg:top-32">
          <div>
            <h1 className="text-4xl md:text-5xl font-headline italic text-primary-container mb-4 leading-tight">{product.name}</h1>
            <div className="flex items-center gap-4">
              <span className="text-3xl font-body font-light text-secondary">${price}</span>
              <div className="h-4 w-[1px] bg-outline-variant/30"></div>
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-secondary text-sm" style={{ fontVariationSettings: "'FILL' 1" }}>star</span>
                <span className="text-sm font-label tracking-widest text-on-surface-variant">{product.rating}</span>
                <span className="text-xs text-on-surface-variant/50">({product.ratings_count} reviews)</span>
              </div>
            </div>
          </div>

          <div className="prose prose-invert max-w-none font-body text-on-surface-variant/80 text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: product.description }} />

          <div className="space-y-6 pt-6 border-t border-outline-variant/10">
            <div className="flex items-center justify-between">
              <span className="font-label text-sm uppercase tracking-[0.1rem] text-on-surface">Quantity</span>
              <div className="flex items-center bg-surface-container-lowest border border-outline-variant/30 rounded-xl px-2 py-1">
                <button onClick={() => setQty(q => Math.max(1, q - 1))} className="w-10 h-10 flex items-center justify-center hover:text-primary transition-colors"><span className="material-symbols-outlined">remove</span></button>
                <span className="px-6 font-body text-on-surface">{qty}</span>
                <button onClick={() => setQty(q => q + 1)} className="w-10 h-10 flex items-center justify-center hover:text-primary transition-colors"><span className="material-symbols-outlined">add</span></button>
              </div>
            </div>
            <button onClick={handleAddToCart} className="w-full silk-gradient py-4 rounded-xl font-label text-on-primary-fixed text-lg font-bold tracking-widest uppercase hover:shadow-[0_0_30px_rgba(225,153,153,0.3)] transition-all active:scale-[0.98]">
              Add to Cart
            </button>
            <button className="w-full py-4 rounded-xl border border-outline-variant/30 text-on-surface font-label text-sm font-semibold tracking-widest uppercase hover:bg-surface-container transition-all">
              Add to Wishlist
            </button>
          </div>
          
          <div className="mt-8 space-y-4">
            <div className="flex items-center gap-4 text-on-surface-variant">
              <span className="material-symbols-outlined text-primary/60">local_shipping</span>
              <span className="text-sm font-body">Complimentary shipping on all orders</span>
            </div>
            <div className="flex items-center gap-4 text-on-surface-variant">
              <span className="material-symbols-outlined text-primary/60">workspace_premium</span>
              <span className="text-sm font-body">Lifetime warranty & care guarantee</span>
            </div>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-32">
          <div className="flex justify-between items-end mb-12 border-b border-outline-variant/10 pb-6">
            <h2 className="text-3xl font-headline italic text-on-surface tracking-wide">Complementary Pieces</h2>
            <Link to={`/products?category=${product.category?.slug}`} className="text-secondary font-medium font-body hover:underline transition-all">Explore Category</Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {related.map(p => <ProductCard key={p.id} product={p} setCart={setCart} />)}
          </div>
        </section>
      )}
    </main>
  )
}

export default ProductDetails
