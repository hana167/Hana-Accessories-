import { Link } from 'react-router-dom'

function About() {
  return (
    <main className="pt-20">
      <section className="relative h-[800px] w-full overflow-hidden hero-gradient">
        <div className="absolute inset-0 z-10"></div>
        <img
          className="w-full h-full object-cover opacity-60"
          src="https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?q=80&w=2070&auto=format&fit=crop"
          alt="Boutique showcase"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-surface/40 to-transparent z-10"></div>
        <div className="absolute inset-0 z-20 flex flex-col justify-center items-center px-8 text-center mt-20">
          <span className="font-label uppercase tracking-[0.2em] text-secondary mb-6 text-sm">Our Heritage</span>
          <h1 className="text-5xl md:text-8xl font-headline italic tracking-tighter text-on-surface mb-8 max-w-5xl">The Art of Refinement.</h1>
          <p className="font-body text-xl text-on-surface-variant max-w-2xl font-light leading-relaxed">
            Hana emerged from a singularity: the desire to create jewelry that speaks softly but resonates deeply.
          </p>
        </div>
      </section>

      <section className="py-32 px-8 bg-surface-container-low relative">
        <div className="max-w-[1440px] mx-auto grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
          <div className="space-y-10">
            <h2 className="text-4xl font-headline italic text-primary">Mastery in Every Curve</h2>
            <p className="font-body text-lg leading-relaxed text-on-surface font-light">
              We meticulously select rare materials, weaving precious metals and luminous stones into timeless silhouettes. Each piece is a testament to the pursuit of absolute elegance.
            </p>
            <div className="grid grid-cols-2 gap-10 pt-8 border-t border-outline-variant/10">
              <div>
                <div className="text-4xl font-headline italic text-secondary mb-3">18K</div>
                <div className="text-[10px] font-label uppercase tracking-widest text-outline">Gold Vermeil</div>
              </div>
              <div>
                <div className="text-4xl font-headline italic text-secondary mb-3">VS1</div>
                <div className="text-[10px] font-label uppercase tracking-widest text-outline">Clarity Diamonds</div>
              </div>
            </div>
          </div>
          <div className="relative group">
            <div className="absolute -inset-8 bg-primary/5 blur-3xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"></div>
            <div className="aspect-[4/5] glass-card rounded-xl overflow-hidden relative z-10">
              <img
                className="w-full h-full object-cover scale-105 group-hover:scale-100 transition-all duration-1000"
                src="https://images.unsplash.com/photo-1596944924616-7b38e7cfac36?q=80&w=1974&auto=format&fit=crop"
                alt="Jewelry making detail"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-32 px-8 text-center max-w-4xl mx-auto">
        <h2 className="font-headline italic text-5xl mb-8 text-on-surface">Curate Your Collection</h2>
        <p className="font-body text-lg text-on-surface-variant mb-12 max-w-2xl mx-auto leading-relaxed">
          The finest details define the most memorable impressions. Discover pieces that highlight your innate brilliance.
        </p>
        <Link to="/products" className="inline-block px-12 py-5 silk-gradient text-on-primary-fixed font-bold uppercase tracking-widest rounded-xl hover:shadow-[0_0_30px_rgba(225,153,153,0.3)] transition-all">
          Explore The Atelier
        </Link>
      </section>
    </main>
  )
}

export default About
