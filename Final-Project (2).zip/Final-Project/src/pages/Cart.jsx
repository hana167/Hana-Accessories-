import { Link } from 'react-router-dom'
import CartItem from '../components/CartItem'
import { getCartTotal } from '../utils/cart'

function Cart({ cart, setCart }) {
  const subtotal = getCartTotal(cart)
  const tax = subtotal * 0.08
  const total = subtotal + tax

  if (cart.length === 0) {
    return (
      <main className="pt-32 pb-24 px-8 max-w-[1600px] mx-auto min-h-screen">
        <header className="mb-12">
          <h1 className="font-headline text-4xl md:text-5xl text-on-surface mb-2">Shopping Bag</h1>
          <p className="text-on-surface-variant font-label tracking-widest text-xs uppercase">Your Curated Selection</p>
        </header>
        <div className="flex flex-col items-center justify-center py-24 text-center glass-card rounded-2xl max-w-4xl mx-auto">
          <span className="material-symbols-outlined text-8xl text-outline-variant/30 mb-8" style={{ fontVariationSettings: "'wght' 100" }}>work</span>
          <h2 className="text-2xl font-headline italic mb-4 text-on-surface">Your bag is empty</h2>
          <p className="font-body text-on-surface-variant/70 mb-10 max-w-md">Discover our collections and add meticulously crafted pieces to your selection.</p>
          <Link to="/products" className="px-10 py-4 silk-gradient text-on-primary-fixed font-semibold tracking-wider uppercase rounded-xl hover:shadow-[0_0_25px_rgba(225,153,153,0.3)] transition-all">
            Explore Collections
          </Link>
        </div>
      </main>
    )
  }

  return (
    <main className="pt-32 pb-20 px-6 md:px-12 max-w-[1600px] mx-auto min-h-screen">
      <header className="mb-16">
        <h1 className="font-headline text-4xl md:text-5xl text-on-surface mb-2">Shopping Bag</h1>
        <p className="text-on-surface-variant font-label tracking-widest text-xs uppercase">Your Curated Selection</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        <div className="lg:col-span-8 space-y-6">
          {cart.map(item => <CartItem key={item.id} item={item} setCart={setCart} />)}
        </div>

        <aside className="lg:col-span-4 sticky top-32">
          <div className="bg-surface-container-low p-8 rounded-xl border border-outline-variant/10 shadow-2xl glass-card">
            <h2 className="font-headline text-2xl mb-8 border-b border-outline-variant/10 pb-6">Summary</h2>
            <div className="space-y-5 mb-8">
              <div className="flex justify-between text-on-surface-variant">
                <span className="font-label text-sm tracking-wide uppercase">Subtotal</span>
                <span className="font-medium font-body">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-on-surface-variant">
                <span className="font-label text-sm tracking-wide uppercase">Shipping</span>
                <span className="font-medium font-body">Complimentary</span>
              </div>
              <div className="flex justify-between text-on-surface-variant">
                <span className="font-label text-sm tracking-wide uppercase">Estimated Tax</span>
                <span className="font-medium font-body">${tax.toFixed(2)}</span>
              </div>
              <div className="pt-6 mt-6 border-t border-outline-variant/20 flex justify-between items-end">
                <span className="font-headline text-xl">Total</span>
                <span className="font-body text-2xl font-semibold text-secondary">${total.toFixed(2)}</span>
              </div>
            </div>
            <Link to="/checkout" className="block w-full text-center py-4 px-6 rounded-xl silk-gradient text-on-primary-fixed font-bold tracking-widest uppercase text-sm shadow-[0_0_30px_rgba(225,153,153,0.4)] hover:shadow-[0_0_50px_rgba(225,153,153,0.6)] active:scale-[0.98] transition-all duration-300">
              Proceed to Checkout
            </Link>
            <div className="mt-8 pt-8 border-t border-outline-variant/20">
              <p className="text-[10px] text-on-surface-variant/50 leading-relaxed text-center font-label uppercase tracking-widest">
                Secure payment processing. All items are shipped in signature Hana velvet packaging.
              </p>
            </div>
          </div>
          <div className="mt-6 p-6 glass-card rounded-xl border border-outline-variant/5 flex items-center gap-4">
            <span className="material-symbols-outlined text-secondary" style={{ fontVariationSettings: "'FILL' 1" }}>workspace_premium</span>
            <div>
              <p className="text-xs font-bold font-body text-on-surface uppercase tracking-widest">Lifetime Warranty</p>
              <p className="text-[10px] font-body text-on-surface-variant uppercase tracking-wider mt-1">Our jewelry is built for eternity.</p>
            </div>
          </div>
        </aside>
      </div>
    </main>
  )
}

export default Cart
