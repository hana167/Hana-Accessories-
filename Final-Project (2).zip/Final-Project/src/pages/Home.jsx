import { Link } from 'react-router-dom'

function Home() {
  return (
    <main className="pt-20">
      <section className="relative min-h-[921px] flex items-center px-8 md:px-20 overflow-hidden hero-gradient">
        <div className="relative z-10 max-w-2xl">
          <h1 className="font-headline italic text-6xl md:text-8xl text-primary leading-tight mb-6">
            Elegance <span className="text-on-surface">in Every</span> Detail
          </h1>
          <p className="text-on-surface-variant text-lg md:text-xl max-w-lg mb-10 font-light leading-relaxed">
            Curated jewelry pieces designed to illuminate your natural grace. Discover the velvet touch of Hana's latest collection.
          </p>
          <div className="flex items-center gap-6">
            <Link to="/products" className="px-10 py-4 rounded-xl silk-gradient text-on-primary font-semibold tracking-wide shadow-[0_0_20px_rgba(255,180,180,0.3)] hover:shadow-[0_0_30px_rgba(255,180,180,0.5)] transition-all duration-300 transform hover:-translate-y-1 active:scale-95">
              Shop Now
            </Link>
            <Link to="/about" className="px-10 py-4 rounded-xl glass-card text-on-surface font-medium border border-outline-variant/30 hover:border-primary/50 transition-all duration-300">
              View Lookbook
            </Link>
          </div>
        </div>
        
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1/2 h-[80%] hidden lg:block pointer-events-none">
          <div className="relative w-full h-full p-12">
            <div className="absolute top-0 right-10 w-72 h-[500px] rounded-full overflow-hidden border-4 border-surface-container-high shadow-2xl z-20 transform translate-y-10">
              <img src="https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=2070&auto=format&fit=crop" 
                   className="w-full h-full object-cover" alt="Luxury jewelry" />
            </div>
            <div className="absolute bottom-0 right-48 w-64 h-64 rounded-xl overflow-hidden border-4 border-surface-container-high shadow-2xl z-10 transform -rotate-12 translate-y-10">
              <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuAY-zKL5RSmmYV9KQxticSaYOEYxm3bi2nLO2jD4HTx4SQ52HVp94OuPijUDfZ08ERVjRE_nXP4J0NIPFRFWHb1U0EMyPNWWRfRbX5qA51UxT8yTmmX2ya_9hUf4JjiJ0BCQlsz-qxAyjQdHKbXbVn3bQYqpHuEPH5yudylZfyuP_n-hJieqHC4GLFCHpswGfAPB53fN2GozfuMEPHIg5O5rq5k6vIEsbRmIooI6ca39beOPTLMKSvgRUb_W_VNWXrEjv6stMSG6ydV" 
                   className="w-full h-full object-cover" alt="Exquisite rings" />
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-8 max-w-[1600px] mx-auto">
        <div className="mb-16">
          <h2 className="font-headline italic text-4xl text-on-surface mb-2">Curated Collections</h2>
          <div className="w-20 h-1 bg-secondary rounded-full"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <Link to="/products?category=bracelets" className="group relative aspect-[4/5] rounded-xl overflow-hidden glass-card cursor-pointer">
            <img src="https://images.unsplash.com/photo-1611591437281-460bfbe1220a?q=80&w=2070&auto=format&fit=crop" 
                 className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-60" 
                 alt="Bracelets" />
            <div className="absolute inset-0 bg-gradient-to-t from-surface via-transparent to-transparent"></div>
            <div className="absolute bottom-8 left-8">
              <span className="text-secondary font-label text-xs tracking-[0.2rem] uppercase block mb-2">Timeless</span>
              <h3 className="font-headline text-3xl italic text-on-surface">Bracelets</h3>
            </div>
          </Link>
          <Link to="/products?category=rings" className="group relative aspect-[4/5] rounded-xl overflow-hidden glass-card cursor-pointer translate-y-0 md:translate-y-8">
            <img src="https://images.squarespace-cdn.com/content/v1/65a01343d4e0b521531eda0a/1704989564589-GER7WDBUJJBBV9LM1JZO/creative+jewellery+photographer" 
                 className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-60" 
                 alt="Rings" />
            <div className="absolute inset-0 bg-gradient-to-t from-surface via-transparent to-transparent"></div>
            <div className="absolute bottom-8 left-8">
              <span className="text-secondary font-label text-xs tracking-[0.2rem] uppercase block mb-2">Signature</span>
              <h3 className="font-headline text-3xl italic text-on-surface">Rings</h3>
            </div>
          </Link>
          <Link to="/products?category=necklaces" className="group relative aspect-[4/5] rounded-xl overflow-hidden glass-card cursor-pointer">
            <img src="https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=1974&auto=format&fit=crop" 
                 className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-60" 
                 alt="Necklaces" />
            <div className="absolute inset-0 bg-gradient-to-t from-surface via-transparent to-transparent"></div>
            <div className="absolute bottom-8 left-8">
              <span className="text-secondary font-label text-xs tracking-[0.2rem] uppercase block mb-2">Refined</span>
              <h3 className="font-headline text-3xl italic text-on-surface">Necklaces</h3>
            </div>
          </Link>
        </div>
      </section>

      <section className="py-24 bg-surface-container-lowest">
        <div className="max-w-[1600px] mx-auto px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <span className="text-primary-container font-label text-sm tracking-widest uppercase">The Essence of Hana</span>
              <h2 className="font-headline italic text-4xl text-on-surface mt-2">Discover Our Pieces</h2>
            </div>
            <Link to="/products" className="text-secondary font-medium flex items-center gap-2 hover:gap-4 transition-all duration-300">
              View all pieces <span className="material-symbols-outlined">arrow_forward</span>
            </Link>
          </div>
        </div>
      </section>

      <section className="py-24 px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary-container/5 blur-[120px] rounded-full pointer-events-none"></div>
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <span className="material-symbols-outlined text-5xl text-primary/30 mb-8">format_quote</span>
          <div className="glass-card p-10 rounded-xl">
            <p className="font-headline text-2xl italic leading-relaxed text-on-surface mb-6">
              "The craftsmanship is beyond anything I've seen. Wearing my Hana necklace makes me feel like I'm wearing a piece of art."
            </p>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full overflow-hidden mb-3 border border-primary/20">
                <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1974&auto=format&fit=crop" 
                     className="w-full h-full object-cover" alt="Customer" />
              </div>
              <h5 className="font-medium tracking-widest text-secondary text-sm uppercase">Helena Vance</h5>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}

export default Home
