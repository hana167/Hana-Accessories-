import { useState } from 'react'
import { Link } from 'react-router-dom'
import { getCartTotal, clearCart } from '../utils/cart'

function Checkout({ cart, setCart }) {
  const subtotal = getCartTotal(cart)
  const tax = subtotal * 0.08
  const total = subtotal + tax

  const [form, setForm] = useState({ fullName: '', email: '', address: '', city: '', state: '', postal: '' })
  const [submitted, setSubmitted] = useState(false)

  function handleChange(e) { setForm({ ...form, [e.target.name]: e.target.value }) }

  function handleSubmit(e) {
    e.preventDefault()
    setCart(clearCart())
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <main className="pt-32 pb-24 px-8 max-w-[1600px] mx-auto min-h-screen flex items-center justify-center">
        <div className="text-center space-y-8 glass-card p-16 rounded-2xl max-w-2xl">
          <div className="w-24 h-24 rounded-full silk-gradient flex items-center justify-center mx-auto shadow-[0_0_60px_rgba(225,153,153,0.4)]">
            <span className="material-symbols-outlined text-on-primary-fixed" style={{ fontSize: '48px', fontVariationSettings: "'wght' 300" }}>check</span>
          </div>
          <h1 className="text-4xl font-headline italic tracking-tighter text-on-surface">Order Confirmed</h1>
          <p className="font-body text-on-surface-variant text-lg">Thank you for choosing Hana. Your exquisite pieces are being prepared and will be shipped in our signature velvet packaging.</p>
          <Link to="/" className="inline-block px-12 py-4 silk-gradient text-on-primary-fixed font-semibold uppercase tracking-widest rounded-xl hover:shadow-[0_0_30px_rgba(225,153,153,0.4)] transition-all">Return Home</Link>
        </div>
      </main>
    )
  }

  if (cart.length === 0) {
    return (
      <main className="pt-32 pb-24 px-8 max-w-[1600px] mx-auto min-h-screen text-center flex flex-col items-center justify-center">
        <h2 className="text-3xl font-headline italic mb-4 text-on-surface">Your bag is empty</h2>
        <Link to="/products" className="text-primary font-body hover:underline">← Explore Collections</Link>
      </main>
    )
  }

  return (
    <main className="pt-32 pb-20 px-6 md:px-12 max-w-[1600px] mx-auto min-h-screen">
      <header className="mb-16">
        <h1 className="font-headline text-4xl md:text-5xl text-on-surface mb-2">Secure Checkout</h1>
        <p className="text-on-surface-variant font-label tracking-widest text-xs uppercase">Complete your acquisition</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
        <div className="lg:col-span-7 space-y-12">
          <section className="glass-card p-8 rounded-2xl">
            <h2 className="text-2xl font-headline italic text-on-surface border-b border-outline-variant/10 pb-6 mb-8">Shipping Information</h2>
            <form id="checkout-form" onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] uppercase tracking-widest font-label text-on-surface-variant">Full Name</label>
                  <input name="fullName" required value={form.fullName} onChange={handleChange} className="bg-surface-container border border-outline-variant/20 focus:border-primary focus:ring-1 focus:ring-primary rounded-lg text-on-surface py-3 px-4 transition-all placeholder:text-outline/40 outline-none font-body text-sm" placeholder="Helena Vance" type="text" />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] uppercase tracking-widest font-label text-on-surface-variant">Email</label>
                  <input name="email" required value={form.email} onChange={handleChange} className="bg-surface-container border border-outline-variant/20 focus:border-primary focus:ring-1 focus:ring-primary rounded-lg text-on-surface py-3 px-4 transition-all placeholder:text-outline/40 outline-none font-body text-sm" placeholder="helena@example.com" type="email" />
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-[10px] uppercase tracking-widest font-label text-on-surface-variant">Address</label>
                <input name="address" required value={form.address} onChange={handleChange} className="bg-surface-container border border-outline-variant/20 focus:border-primary focus:ring-1 focus:ring-primary rounded-lg text-on-surface py-3 px-4 transition-all placeholder:text-outline/40 outline-none font-body text-sm" placeholder="123 Luxury Avenue" type="text" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] uppercase tracking-widest font-label text-on-surface-variant">City</label>
                  <input name="city" required value={form.city} onChange={handleChange} className="bg-surface-container border border-outline-variant/20 focus:border-primary focus:ring-1 focus:ring-primary rounded-lg text-on-surface py-3 px-4 transition-all placeholder:text-outline/40 outline-none font-body text-sm" placeholder="Los Angeles" type="text" />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] uppercase tracking-widest font-label text-on-surface-variant">State</label>
                  <input name="state" required value={form.state} onChange={handleChange} className="bg-surface-container border border-outline-variant/20 focus:border-primary focus:ring-1 focus:ring-primary rounded-lg text-on-surface py-3 px-4 transition-all placeholder:text-outline/40 outline-none font-body text-sm" placeholder="CA" type="text" />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] uppercase tracking-widest font-label text-on-surface-variant">Postal Code</label>
                  <input name="postal" required value={form.postal} onChange={handleChange} className="bg-surface-container border border-outline-variant/20 focus:border-primary focus:ring-1 focus:ring-primary rounded-lg text-on-surface py-3 px-4 transition-all placeholder:text-outline/40 outline-none font-body text-sm" placeholder="90210" type="text" />
                </div>
              </div>
            </form>
          </section>

          <section className="glass-card p-8 rounded-2xl">
            <h2 className="text-2xl font-headline italic text-on-surface border-b border-outline-variant/10 pb-6 mb-8">Payment Details</h2>
            <div className="space-y-6">
              <div className="flex flex-col gap-2">
                <label className="text-[10px] uppercase tracking-widest font-label text-on-surface-variant">Card Number</label>
                <div className="flex items-center bg-surface-container px-4 py-3 rounded-lg border border-outline-variant/20 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary transition-all">
                  <span className="material-symbols-outlined text-outline mr-3" style={{ fontSize: '18px' }}>credit_card</span>
                  <input placeholder="1234  5678  9012  3456" maxLength={19} className="bg-transparent outline-none flex-1 text-sm font-mono tracking-widest text-on-surface placeholder:text-outline/40" type="text" readOnly />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-6">
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] uppercase tracking-widest font-label text-on-surface-variant">Expiry Date</label>
                  <input placeholder="MM / YY" className="bg-surface-container px-4 py-3 rounded-lg border border-outline-variant/20 text-sm font-mono tracking-widest text-on-surface placeholder:text-outline/40 outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all" readOnly />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] uppercase tracking-widest font-label text-on-surface-variant">CVV</label>
                  <input placeholder="•••" className="bg-surface-container px-4 py-3 rounded-lg border border-outline-variant/20 text-sm font-mono tracking-widest text-on-surface placeholder:text-outline/40 outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all" readOnly />
                </div>
              </div>
            </div>
          </section>
        </div>

        <aside className="lg:col-span-5 sticky top-32">
          <div className="bg-surface-container-low p-10 rounded-2xl border border-outline-variant/10 shadow-[0_20px_60px_rgba(0,0,0,0.15)] glass-card">
            <h2 className="text-2xl font-headline italic text-on-surface mb-8 border-b border-outline-variant/10 pb-6">Your Order</h2>
            <div className="space-y-6 mb-8 max-h-[400px] overflow-y-auto no-scrollbar">
              {cart.map(item => (
                <div key={item.id} className="flex gap-4 items-center">
                  <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 bg-surface-container-high border border-outline-variant/5">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-grow flex flex-col justify-center min-w-0">
                    <div className="flex justify-between items-start gap-2">
                      <h3 className="text-lg font-headline italic text-on-surface line-clamp-1 flex-1">{item.name}</h3>
                      <span className="font-body font-semibold text-secondary whitespace-nowrap">${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                    <p className="text-[10px] font-label text-outline mt-1 uppercase tracking-widest">Qty: {item.quantity}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="space-y-5 pt-6 border-t border-outline-variant/15">
              <div className="flex justify-between font-body text-sm"><span className="text-on-surface-variant uppercase tracking-widest text-[10px] font-bold">Subtotal</span><span className="text-on-surface">${subtotal.toFixed(2)}</span></div>
              <div className="flex justify-between font-body text-sm"><span className="text-on-surface-variant uppercase tracking-widest text-[10px] font-bold">Shipping</span><span className="text-on-surface">Complimentary</span></div>
              <div className="flex justify-between font-body text-sm"><span className="text-on-surface-variant uppercase tracking-widest text-[10px] font-bold">Tax</span><span className="text-on-surface">${tax.toFixed(2)}</span></div>
              <div className="flex justify-between items-center pt-6 mt-2 border-t border-outline-variant/15">
                <span className="font-headline text-2xl text-on-surface">Total</span>
                <span className="font-body text-3xl font-semibold text-secondary">${total.toFixed(2)}</span>
              </div>
            </div>
            
            <button form="checkout-form" type="submit" className="w-full mt-10 py-5 rounded-xl silk-gradient text-on-primary-fixed font-bold tracking-widest uppercase flex justify-center items-center gap-3 group shadow-[0_0_30px_rgba(225,153,153,0.3)] hover:shadow-[0_0_50px_rgba(225,153,153,0.5)] active:scale-[0.98] transition-all">
              <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>lock</span>
              Complete Order
            </button>
            
            <div className="mt-8 flex items-center justify-center gap-3 text-outline-variant/50">
              <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>encrypted</span>
              <span className="text-[10px] font-label uppercase tracking-widest">Secure TLS 256-bit Encryption</span>
            </div>
          </div>
        </aside>
      </div>
    </main>
  )
}

export default Checkout
