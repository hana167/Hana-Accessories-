import db from '../data/db.json'

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms))

export async function getProducts({ search = '', page = 1, category = '', ordering = '-rating', pageSize = 12 } = {}) {
  await delay(300)
  let results = [...db.products]

  if (search) {
    const query = search.toLowerCase()
    results = results.filter(product => product.name.toLowerCase().includes(query))
  }

  if (category) {
    const catObj = db.categories.find(c => 
      c.id === parseInt(category) || 
      c.slug === category || 
      c.name.toLowerCase() === category.toLowerCase()
    )
    if (catObj) {
      results = results.filter(product => product.category.id === catObj.id)
    } else {
      results = []
    }
  }

  if (ordering === '-rating') {
    results.sort((a, b) => b.rating - a.rating)
  } else if (ordering === 'rating') {
    results.sort((a, b) => a.rating - b.rating)
  } else if (ordering === '-released') {
    results.sort((a, b) => new Date(b.released) - new Date(a.released))
  } else if (ordering === 'name') {
    results.sort((a, b) => a.name.localeCompare(b.name))
  }

  const start = (page - 1) * pageSize
  const paginatedResults = results.slice(start, start + pageSize)

  return {
    count: results.length,
    results: paginatedResults
  }
}

export async function getProductById(id) {
  await delay(300)
  const product = db.products.find(p => p.id === parseInt(id))
  return product || null
}

export async function getRelatedProducts(id) {
  await delay(300)
  const product = db.products.find(p => p.id === parseInt(id))
  if (!product) return { results: [] }
  
  const related = db.products.filter(p => p.id !== product.id && p.category.id === product.category.id)
  
  return { results: related }
}

export async function getCategories() {
  await delay(300)
  return { results: db.categories }
}

export function getStablePrice(product) {
  if (product.price) return product.price.toFixed(2)
  return "99.00"
}
