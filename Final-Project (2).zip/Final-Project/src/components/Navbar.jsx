import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { getCartCount } from '../utils/cart'

function Navbar({ cart }) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const navigate = useNavigate()
  const cartCount = getCartCount(cart)

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/products', label: 'Collections' },
    { to: '/about', label: 'About' },
    { to: '/contact', label: 'Contact' },
  ]

  function handleSearch(e) {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`)
      setSearchQuery('')
      setMobileOpen(false)
    }
  }

  return (
    <nav className="fixed top-0 w-full flex justify-between items-center px-8 py-4 max-w-full bg-surface/60 backdrop-blur-md z-50 shadow-[0_20px_40px_-15px_rgba(225,153,153,0.08)]">
      <div className="flex items-center gap-12">
        <Link to="/" className="text-2xl font-headline italic text-primary-container">Hana</Link>
        <div className="hidden md:flex gap-8">
          {navLinks.map(link => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                isActive
                  ? 'text-secondary border-b-2 border-secondary pb-1 font-label tracking-[0.05rem]'
                  : 'text-on-surface-variant hover:text-primary-container transition-all duration-300 hover:scale-105 font-label tracking-[0.05rem]'
              }
            >
              {link.label}
            </NavLink>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-6 text-on-surface-variant">
        <form onSubmit={handleSearch} className="hidden lg:flex items-center bg-surface-container-lowest px-4 py-2 rounded-lg border-b border-transparent focus-within:border-primary-container transition-all">
          <span className="material-symbols-outlined text-outline mr-2" style={{ fontSize: '16px' }}>search</span>
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="bg-transparent border-none focus:ring-0 text-xs tracking-widest text-on-surface-variant outline-none w-36"
            placeholder="Search jewelry..."
            type="text"
          />
        </form>

        <Link to="/cart" className="relative hover:text-primary-container transition-all duration-300 hover:scale-105 active:scale-95">
          <span className="material-symbols-outlined">shopping_bag</span>
          {cartCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-primary-container text-on-primary text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full">
              {cartCount > 9 ? '9+' : cartCount}
            </span>
          )}
        </Link>
        <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden hover:text-primary-container transition-all duration-300 hover:scale-105 active:scale-95">
          <span className="material-symbols-outlined">{mobileOpen ? 'close' : 'menu'}</span>
        </button>
      </div>

      {mobileOpen && (
        <div className="absolute top-full left-0 w-full bg-surface/95 backdrop-blur-xl border-t border-outline-variant/20 px-8 py-6 flex flex-col gap-4 shadow-lg">
          {navLinks.map(link => (
            <NavLink
              key={link.to}
              to={link.to}
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) =>
                isActive
                  ? 'text-primary-container font-headline tracking-widest text-lg'
                  : 'text-on-surface-variant font-headline tracking-widest text-lg hover:text-primary-container transition-colors'
              }
            >
              {link.label}
            </NavLink>
          ))}
          <form onSubmit={handleSearch} className="flex items-center bg-surface-container-lowest px-4 py-3 rounded-lg mt-2">
            <span className="material-symbols-outlined text-outline mr-2" style={{ fontSize: '16px' }}>search</span>
            <input
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="bg-transparent border-none focus:ring-0 text-sm tracking-widest text-on-surface-variant outline-none flex-1"
              placeholder="Search jewelry..."
              type="text"
            />
          </form>
        </div>
      )}
    </nav>
  )
}

export default Navbar
