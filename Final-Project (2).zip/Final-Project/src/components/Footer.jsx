import { Link } from 'react-router-dom'

function Footer() {
  return (
    <footer className="bg-surface border-t border-outline-variant/10 mt-20">
      <div className="w-full py-16 px-8 grid grid-cols-1 md:grid-cols-4 gap-12 max-w-[1600px] mx-auto">
        <div className="space-y-6">
          <Link to="/" className="text-xl font-headline italic text-primary-container">Hana</Link>
          <p className="text-on-surface-variant/70 font-body text-sm leading-relaxed max-w-sm">
            Defining elegance through a curation of pieces that speak of sophistication and artistry. Crafted for the modern muse.
          </p>
          <div className="flex gap-4">
            <span className="material-symbols-outlined text-on-surface-variant/70 cursor-pointer hover:text-primary-container transition-all">public</span>
            <span className="material-symbols-outlined text-on-surface-variant/70 cursor-pointer hover:text-primary-container transition-all">camera_enhance</span>
            <span className="material-symbols-outlined text-on-surface-variant/70 cursor-pointer hover:text-primary-container transition-all">mail</span>
          </div>
        </div>
        
        <div>
          <h4 className="font-headline text-on-surface text-lg mb-6">The Boutique</h4>
          <ul className="space-y-4">
            <li><Link to="/products" className="text-on-surface-variant/70 hover:text-primary-container transition-all font-body text-sm">Collections</Link></li>
            <li><Link to="/products" className="text-on-surface-variant/70 hover:text-primary-container transition-all font-body text-sm">New Arrivals</Link></li>
            <li><Link to="/products" className="text-on-surface-variant/70 hover:text-primary-container transition-all font-body text-sm">Best Sellers</Link></li>
            <li><Link to="/about" className="text-on-surface-variant/70 hover:text-primary-container transition-all font-body text-sm">About Us</Link></li>
          </ul>
        </div>
        
        <div>
          <h4 className="font-headline text-on-surface text-lg mb-6">Support</h4>
          <ul className="space-y-4">
            <li><Link to="/" className="text-on-surface-variant/70 hover:text-primary-container transition-all font-body text-sm">Terms of Service</Link></li>
            <li><Link to="/" className="text-on-surface-variant/70 hover:text-primary-container transition-all font-body text-sm">Shipping & Returns</Link></li>
            <li><Link to="/contact" className="text-on-surface-variant/70 hover:text-primary-container transition-all font-body text-sm">Contact Us</Link></li>
          </ul>
        </div>
        
        <div>
          <h4 className="font-headline text-on-surface text-lg mb-6">Newsletter</h4>
          <p className="text-on-surface-variant/70 font-body text-xs mb-4">Join our elite circle for exclusive previews.</p>
          <div className="flex gap-2">
            <input className="bg-surface-container-lowest border border-outline-variant/10 rounded-lg text-sm w-full px-4 py-2 focus:outline-none focus:border-primary-container transition-colors" placeholder="Email address" type="email" />
            <button className="bg-primary/20 text-primary-container px-4 py-2 rounded-lg font-medium hover:bg-primary/30 transition-all">
              <span className="material-symbols-outlined text-sm">arrow_forward</span>
            </button>
          </div>
        </div>
      </div>
      <div className="border-t border-outline-variant/10 py-8 px-8 text-center">
        <p className="text-xs font-label tracking-[0.05rem] text-on-surface-variant/40">© 2026 Hana Accessories. Crafted for Elegance.</p>
      </div>
    </footer>
  )
}

export default Footer
