function SkeletonCard() {
  return (
    <div className="flex flex-col glass-card rounded-xl overflow-hidden animate-pulse">
      <div className="aspect-[4/5] bg-surface-container-low w-full"></div>
      <div className="p-6 flex flex-col flex-1">
        <div className="flex justify-between items-start mb-3">
          <div className="h-5 bg-surface-container-high rounded w-2/3"></div>
          <div className="h-5 bg-surface-container-high rounded w-1/4"></div>
        </div>
        <div className="h-3 bg-surface-container w-1/3 rounded mb-6"></div>
        <div className="mt-auto h-12 bg-surface-container-high rounded-lg w-full"></div>
      </div>
    </div>
  )
}

export default SkeletonCard
