import { removeFromCart, updateQuantity } from '../utils/cart'

function CartItem({ item, setCart }) {
  function handleRemove() { setCart(removeFromCart(item.id)) }
  function handleIncrease() { setCart(updateQuantity(item.id, item.quantity + 1)) }
  function handleDecrease() { setCart(updateQuantity(item.id, item.quantity - 1)) }

  return (
    <div className="glass-card p-6 rounded-xl flex flex-col md:flex-row items-center gap-6 group hover:bg-surface-container-high/50 transition-colors duration-500">
      <div className="w-32 h-32 md:w-40 md:h-40 overflow-hidden rounded-xl bg-surface-container-lowest shrink-0">
        <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
      </div>
      <div className="flex-grow flex flex-col md:flex-row justify-between w-full gap-4">
        <div className="space-y-1">
          <h3 className="font-headline text-xl text-on-surface line-clamp-1" title={item.name}>{item.name}</h3>
          <p className="text-on-surface-variant text-[10px] uppercase font-light tracking-widest">{item.category}</p>
          <p className="text-secondary font-medium pt-2">${(item.price * item.quantity).toFixed(2)}</p>
        </div>
        <div className="flex items-center gap-8 mt-4 md:mt-0">
          <div className="flex items-center bg-surface-container-lowest rounded-full px-2 py-1 border border-outline-variant/20">
            <button onClick={handleDecrease} className="w-8 h-8 flex items-center justify-center text-on-surface-variant hover:text-primary transition-colors">
              <span className="material-symbols-outlined text-lg">remove</span>
            </button>
            <span className="px-4 text-on-surface font-medium">{item.quantity}</span>
            <button onClick={handleIncrease} className="w-8 h-8 flex items-center justify-center text-on-surface-variant hover:text-primary transition-colors">
              <span className="material-symbols-outlined text-lg">add</span>
            </button>
          </div>
          <button onClick={handleRemove} className="text-on-surface-variant hover:text-error transition-colors p-2">
            <span className="material-symbols-outlined">delete</span>
          </button>
        </div>
      </div>
    </div>
  )
}

export default CartItem
