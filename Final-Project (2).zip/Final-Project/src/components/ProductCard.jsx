import { Link } from 'react-router-dom'
import { addToCart } from '../utils/cart'
import { getStablePrice } from '../utils/api'

function ProductCard({ product, setCart }) {
  const price = getStablePrice(product)
  const image = product.background_image || 'https://via.placeholder.com/400x500?text=No+Image'
  const category = product.category?.name || 'Accessory'

  function handleAddToCart(e) {
    e.preventDefault()
    const item = { id: product.id, name: product.name, image, price: parseFloat(price), category }
    const newCart = addToCart(item)
    setCart(newCart)
  }

  return (
    <Link to={`/products/${product.id}`} className="group relative flex flex-col glass-card rounded-xl overflow-hidden hover:scale-[1.02] transition-all duration-500 lume-effect">
      <div className="aspect-[4/5] overflow-hidden relative">
        <img src={image} alt={product.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
        <div className="absolute inset-0 bg-gradient-to-t from-surface/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
      </div>
      <div className="p-6 flex flex-col flex-1">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-headline text-xl text-on-surface group-hover:text-primary transition-colors line-clamp-1 truncate" title={product.name}>{product.name}</h3>
          <span className="text-secondary font-label ms-2">${parseFloat(price).toFixed(0)}</span>
        </div>
        <p className="text-sm font-body text-on-surface-variant/70 mb-6 uppercase tracking-wider text-[10px]">{category}</p>
        <button onClick={handleAddToCart} className="mt-auto w-full silk-gradient py-3 rounded-lg font-label text-on-primary-fixed font-semibold tracking-wider hover:shadow-[0_0_25px_rgba(225,153,153,0.4)] transition-all active:scale-95">
          Add to Cart
        </button>
      </div>
    </Link>
  )
}

export default ProductCard
