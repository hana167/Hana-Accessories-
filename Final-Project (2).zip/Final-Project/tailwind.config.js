/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        "primary": "#ffb4b4",
        "primary-container": "#e19999",
        "on-primary": "#512123",
        "on-primary-fixed": "#370d0f",
        "secondary": "#e9c349",
        "secondary-container": "#af8d11",
        "surface": "#131313",
        "surface-container": "#201f1f",
        "surface-container-low": "#1c1b1b",
        "surface-container-high": "#2a2a2a",
        "surface-container-highest": "#353534",
        "surface-container-lowest": "#0e0e0e",
        "surface-bright": "#393939",
        "on-surface": "#e5e2e1",
        "on-surface-variant": "#d7c2c1",
        "outline": "#9f8c8c",
        "outline-variant": "#524343",
        "error": "#ffb4ab",
        "background": "#131313",
        "tertiary": "#dfc0c3",
        "tertiary-container": "#c2a5a8",
      },
      fontFamily: {
        headline: ["Noto Serif", "serif"],
        body: ["Manrope", "sans-serif"],
        label: ["Manrope", "sans-serif"],
      },
      borderRadius: {
        DEFAULT: "0.25rem",
        lg: "0.5rem",
        xl: "0.75rem",
        "2xl": "1rem",
        full: "9999px",
      },
    },
  },
  plugins: [],
}
